//  <root>/routes/index.js
//

var utilities = require('../middleware/utilities')
  , config = require('../config')
  , routes_versione = '0.1.0a'
;

module.exports.index = index;
module.exports.login = login;
module.exports.logOut = logOut;
module.exports.admin = admin;

function admin(req, res){
  console.log('routes - adminpage - route /admin - START');
  res.locals.liveurl = shared.liveurl;
  res.locals.usrid = req.user.usrid;
  res.locals.username = req.user.username;
  res.locals.userdisplayname = req.user.userdisplayName;
	//res.locals.token = req.csrfToken();  //gia' in utilities - qui non serve piu'
  res.locals.sessionid = req.session.sessionid;
  console.log('routes - adminpage - res.locals.sessionid: '+res.locals.sessionid);
  res.locals.listavars = shared.vars;
  console.log("routes - adminpage - admin listavars:\n"+JSON.stringify(res.locals.listavars));
	res.render('admin', {title: 'Admin'});
  console.log('routes - adminpage - route /admin - END');
};

function index(req, res){
  res.locals.hserverIP = req.locals.hserverIP
	res.render('index', {title: 'NodeSimple home page'});
};

function login(req, res){
	res.render('login', {title: 'Login', message: req.flash('error')});
};

function logOut(req, res){
  utilities.logOut(req);
  res.redirect('/');
};
