// index-syslog
// Due funzioni:
//   1.- Gestione dei messaggi di log provenienti da logspout
//   2.- app (express) per la visualizzazione dei log da browser
//
const Redis = require('ioredis');
var
	  bodyParser = require('body-parser')
  ,      dgram = require('dgram')
  ,    dumpvar = require('util-inspect')
  ,    express = require('express')
	,   partials = require('express-partials')
//  ,       fs = require('fs')
  , getRawBody = require('raw-body')
//  ,     http = require('http')
//  ,       ip = require('ip')
  ,     routes = require('./routes')
  ,       util = require('util')
	,  utilities = require('./middleware/utilities')
  , http_port = 7003
// sezione UDP
  , PORT = 1514
  , HOST = '0.0.0.0'
  , server = dgram.createSocket('udp4')
  , e_id = 0      // contatore dei messaggi, letto da redis                         *** DA AGGIUSTARE ***
  , logvalue
  , ngdebugname = 'base:debug:0.00.01:varname'   // debug value from nginx
  , mycountername = 'base:user:0.00.01:counter'  // this server main counter name
  , hiscountername = 'base:app:0.00.01:counter'  // counter name for the app server
  , mycount = 0                                  // this server main counter value
;
const gtbase_logvar = 'GTBASE:0.00.01:logvar'    // variabile contenente un debug log
const gtbase_loglist = 'GTBASE:0.00.01:loglist'  // lista degli ultimi (list_maxlen) debug logs
const list_maxlen = 10                           // lunghezza massima della lista

//-------------------------------------------------------- utility function for async middleware
// ref.:  http://www.acuriousanimal.com/2018/02/15/express-async-middleware.html
const asyncHandler = fn => (req, res, next) =>
  Promise
    .resolve(fn(req, res, next))
    .catch(next)
  ;

// ------------------------------------------------------- funzioni asincrone redis
const redisport = 6379;                   // define & connect to redis
const redishost = 'redis';
const redis = new Redis(redisport, redishost);
async function incrvar(varname) {// increment and read mycounter
    try {
        const value = await redis.incr(varname);
        return value;
    } catch (error) {
        return error;
    }
}
async function getvar(varname) {// read his counter
    try {
        const value = await redis.get(varname);
        return value;
    } catch (error) {
        return error;
    }
}
async function setvar(varname, value) {// read his counter
    try {
        const result = await redis.set(varname, value);
        return result;
    } catch (error) {
        return error;
    }
}
async function listadd(listname, value) {// read his counter
    try {
        const result = await redis.lpush(listname, value);
        return result;
    } catch (error) {
        return error;
    }
}
async function listsub(listname) {// read his counter
    try {
        const result = await redis.rpop(listname);
        return result;
    } catch (error) {
        return error;
    }
}
async function getlist(listname) {// read his counter
    try {
        const result = await redis.lrange(listname, 0, -1);
        return result;
    } catch (error) {
        return error;
    }
}
async function getelement(listname, index) {// read his counter
    try {
        const result = await redis.lrange(listname, index, index);
        return result;
    } catch (error) {
        return error;
    }
}

// INSERIRE qui le inizializzazioni da redis                                                        *** DA FARE ***

//???

////////////////////////////////////////////////////////////////////////////////////////////////////
//
//   Sezione EXPRESS:   sito express per gestire il Single-Sign-On   (SSO)
//
////////////////////////////////////////////////////////////////////////////////////////////////////
//
app = express();

app.use(async function(req, res, next){// funzione 'contatore
  //aspetta il contatore
    mycount = await incrvar(mycountername);
    ngdebug = await getvar(ngdebugname);
	next();
});


//  External homepage with object - through the nginx proxy
app.get('/user/:qualcosa', async (req, res, next) => {
  try {
    res.type('.html')
    var i;
    res.write('Hello, I am syslog, listening from the internet via the nginx proxy ! <br>');
    res.write('This is the "/user/:qualcosa" path<br><br>');
    res.write('Debug list:<br>');
    for (i = 0; i < list_maxlen; i++) {
      const log_value = await getelement(gtbase_loglist, i);
      res.write('<br>'+log_value);
    } 
    res.write('<br>You called user with qualcosa: '+req.params.qualcosa);
    res.write('<br>Query parameters are:<br>'+JSON.stringify(req.query));
    res.write('<br>My counter value is: '+mycount);
    res.write('<br><br>nginx debug string: '+ngdebug);
    res.write('<br><br>------------------------- END');
    res.end();
    // NOTA:  next() non va eseguito !!!
  } catch (error) {
    next(error);    
  }
});


//  External homepage with path - through the nginx proxy
app.get('/user/*', async (req, res, next) => {
  try {
    res.type('.html')
    res.write('Hello, I am syslog, listening from the internet via the nginx proxy ! <br><br>');
    res.write('This is the "/user" path<br><br>');
    res.write('Debug list:<br>');
    for (i = 0; i < list_maxlen; i++) {
      const log_value = await getelement(gtbase_loglist, i);
      res.write('<br>'+log_value);
    } 
    res.write('<br>You called me with the path: '+req.path);
    res.write('<br>Query parameters are:<br>'+JSON.stringify(req.query));
    res.write('<br>I counted up to '+mycount);
    res.write('<br>nginx debug string: '+ngdebug);
    res.write('<br>------------------------- END');
    res.end();
    // NOTA:  next() non va eseguito !!!
  } catch (error) {
    next(error);    
  }
});

//  catch all page - can also be called directly trough the container address-port 
app.get('/.*', async (req, res, next) => {
  try {
    res.type('.html')
    res.write('Hello, I am syslog, listening on port '+http_port+' ! <br>');
    const log_value = await getvar(gtbase_logvar);
    res.write('Debug string:<br>'+log_value+'<br><br>');
    res.write('<br>You called me with the url: '+req.url);
    res.write('<br>query parameters are: '+JSON.stringify(req.query));
    res.write('<br><br>nginx debug string: '+ngdebug);
    res.write('<br>------------------------- END');
    res.end();
    next();
  } catch (error) {
    next(error);    
  }
});

// aspettare qui le letture iniziali da redis                                      *** DA VEDERE ***
app.listen(http_port, function () {
  console.log('Syslog is listening on port '+http_port+' !\n');
});

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//                                                                                 FINE zona express
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//  Gestione dei messaggi LOGSPOUT dalle applicazioni locali                      INIZIO zona SYSLOG
////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  *** DA AGGIORNARE ***
//  Valori assegnati a msg.type
//    "333"         messaggio iniziale al 'listening' dei pacchetti udp
//    "401"         messaggio generato da index-syslog di tipo utf-8
//    "666"         pacchetto ricevuto in codifica diversa da utf-8                                                        *** cambiare in 601  ????
//  
//   
//  Valori osservati nei messaggi utf-8
//  
//  

server.on('error', (err) => {
  console.log(`UDP server error:\n${err.stack}`);
  server.close();
});

server.on('message', async function (message, remote) {
// -----------------------  formato buffer messaggi:
// Oggetto JS:
//    {     "type":"001"
//    ,   "source":"<14>1"
//    ,     "time":"2018-01-29T18:08:59Z"
//    ,"container":"6417d30355b4"
//    ,  "service":"redis"
//    ,     "s_id":"6442"
//    ,      "log":"- - 1:M 29 Jan 18:08:59.141 * Background saving terminated with success"
//    }
// slice(0,p1)            
// source visti:
//   <14>1     logspout  (mytasks.py, nginx, ...?)
//   <11>1     container uwsgi  (log di sistema)
//
  var start
    , len = 0
    , coda = ''
    , p1 = 6    // posizione finale campo source
    , p2 = 27   // posizione finale campo time
    , p3 = 40   // posizione finale campo container id
    , msg = {}  // oggetto log --> oggetto evento
    , args = []
    , ngxargs = []
    , argslen        // vale sia per args che ngxargs
    , var_sep = "!:"
    , msglog    // utile nel DEBUG ------------------------                    alla fine: AGGIUSTARE
    , time_error = "[00/00/00000:00:00:00 +0000]" // ERRORE su ngxtime
    , msgtype = "401";// valore provvisorio, potrebbe essere modificato piu' avanti
  ;
  
  if(typeof message.toString('utf8')){
    //  La parte iniziale dei messaggi logspout appare essere un prefisso contenente
    //  il tmpo di invio e varie informazioni sull'ambiente docker
    //  Per convenienza, estraiamo qui queste informazioni, per un piu' gacile uso da
    //  parte di altri programmi
    //  
    //  Parte iniziale logspout, tradotta in index-syslog:
    //        msg.data = message.toString('utf8');
    //    
    //      <14>1 2017-11-07T14:06:19Z 297a71620152 uwsgi 2660 -
    //      0123456789012345678901234567890123456789012345678901
    //                1         2         3         4         5
    //            
    //  costanti per l'estrazione:  p1,.. : 6, 27, 40 ....             <== vedi parte iniziale sopra
    //
    //  parametri memorizzati in redis:
    //    type         vedi 'Valori assegnati a msg.type' all'inizio della zona syslog
    //    id           identificatore univoco (intero sequenziale mem. in redis)                    *** IN CORSO ***
    //    message      coda del messaggio logspout, dopo la parte iniziale
    //
    msgtype = '401';
    msg.source = safeTrim(message.slice(0,p1).toString());//       <14>1             <== e se non e' <14>1 ?  *** DA AGGIUSTARE ***
    msg.time = safeTrim(message.slice(p1,p2).toString()); //       2017-11-07T14:03:19Z
    msg.container = safeTrim(message.slice(p2,p3).toString()); //  297a71620152
    coda = safeTrim(message.slice(p3).toString());//               2017-11-07T14:03:19Z
    len = coda.indexOf(" ");
    //msg.servicelen = len;
    msg.service = ''; // nome alfanumerico del container
    if(len > 0){
      msg.service = coda.slice(0,len);// service name  (definito in docker-compose.yml)
      coda = coda.slice(len+1);
    }
    len = coda.indexOf(" ");
    //msg.s_idlen = len;
    msg.s_id = '';// container numeric id - dovrebbe corrispondere a msg.service (nome del servizio)
    msglog = coda;// messaggio di log generato dal servizio
    if(len > 0){
      msg.s_id = coda.slice(0,len); 
      msglog = coda.slice(len+1);//   
    }
    msg.msglog = msglog;    
    //--------------------------------  mem UTF8 in redis
  }else{
    msgtype = "666 - non-utf8";//--------------------------------messaggio con codifica sconosciuta
    msg.data = message;  // utile solo nel debug iniziale
  }
  await debuglog(msgtype, msg);
});

server.on('listening', function () {
  var address = server.address();
  var message =  {message:'Sono passato dalla udp listening function', address: address};
  debuglog('333', message); // memorizza in redis
});

server.bind(PORT);

//\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\
//                                                                                  FINE zona SYSLOG
////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
//=========================================================================================================================
//                                                                                                 /==  HELPER FUNCTONS  ==
//================================================================================================/

function safeJSONparse(payload){ try{//---  se non ci sono errori ritorna l'oggetto JSON, altrimenti false 
    var p = JSON.parse(payload);
    return p;
  }catch(myError) {
    console.log('catch_error() - ERRORE safeJSON.parse(): ' + myError.name + ' | Message:' + myError.message);
    return false;
}};

function safeTrim(stringa){ try{//---  se non ci sono errori ritorna l'oggetto JSON, altrimenti false 
    if(stringa){
      return stringa.trim();
    }else{
      return '';
    }
  }catch(myError) {
    console.log('catch_error() - ERRORE safeTrim(): ' + myError.name + ' | Message:' + myError.message);
    return '';
}};

async function debuglog(type, debugmsg){//---  generazione dei messaggi di DEBUG
  //---  formato eventi definito all'inizio
  // 
  // ref.:  https://thisdavej.com/guides/redis-node/node/hashes.html
  var msg = {}
  ;
  msg.type = type
  e_id ++;// ricordarsi di aggiustare redis db, quando implementato                                 *** DA AGGIUSTARE ***
  msg.id = e_id; 
  msg.message = debugmsg;
  const listlen = await listadd(gtbase_loglist, JSON.stringify(msg));
  if (listlen > list_maxlen){
    await listsub(gtbase_loglist)
  }
  return;
};

//================================================================================================\
//                                                                                                 \==  HELPER FUNCTIOS  ==
//=========================================================================================================================


    //       
    //    msg.data = message.toString('utf8');
    //    
    //  <14>1 2017-11-07T14:06:19Z 297a71620152 uwsgi 2660 -
    //  0123456789012345678901234567890123456789012345678901
    //            1         2         3         4         5
    //            
    //  costanti p1,.. : 6, 27, 40 ....                                      <== vedi var sopra
    //
