#!/bin/bash
#
#  startup file per contenitore sviluppi vuejs
#
#############
#
echo
echo "cloud: lancio del server app-http"
node index-app.js
echo "ho eseguito:  node index-app.js"
echo "-----------------------------"
echo 